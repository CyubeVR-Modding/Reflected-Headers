#include "AITask.h"

UAITask::UAITask() {
    this->OwnerController = NULL;
}

