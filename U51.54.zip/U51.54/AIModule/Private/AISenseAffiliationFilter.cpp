#include "AISenseAffiliationFilter.h"

FAISenseAffiliationFilter::FAISenseAffiliationFilter() {
    this->bDetectEnemies = false;
    this->bDetectNeutrals = false;
    this->bDetectFriendlies = false;
}

