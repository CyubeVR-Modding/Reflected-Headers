#include "GenericTeamId.h"

FGenericTeamId::FGenericTeamId() {
    this->TeamID = 0;
}

