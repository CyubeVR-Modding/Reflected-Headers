#include "BTDecorator_ConeCheck.h"

UBTDecorator_ConeCheck::UBTDecorator_ConeCheck() {
    this->ConeHalfAngle = 45.00f;
}

