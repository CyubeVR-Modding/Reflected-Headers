#include "EnvQueryNode.h"

UEnvQueryNode::UEnvQueryNode() {
    this->VerNum = 0;
}

