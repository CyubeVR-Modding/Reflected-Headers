#include "AISenseEvent_Hearing.h"

UAISenseEvent_Hearing::UAISenseEvent_Hearing() {
}

