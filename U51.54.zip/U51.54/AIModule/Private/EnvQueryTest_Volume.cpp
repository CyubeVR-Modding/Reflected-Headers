#include "EnvQueryTest_Volume.h"

UEnvQueryTest_Volume::UEnvQueryTest_Volume() {
    this->VolumeContext = NULL;
    this->VolumeClass = NULL;
    this->bDoComplexVolumeTest = false;
}

