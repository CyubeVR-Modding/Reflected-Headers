#include "AIMoveRequest.h"

FAIMoveRequest::FAIMoveRequest() {
    this->GoalActor = NULL;
}

