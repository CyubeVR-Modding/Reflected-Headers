#include "AISense_Damage.h"

class AActor;
class UObject;

void UAISense_Damage::ReportDamageEvent(UObject* WorldContextObject, AActor* DamagedActor, AActor* Instigator, float DamageAmount, FVector EventLocation, FVector HitLocation, FName Tag) {
}

UAISense_Damage::UAISense_Damage() {
}

