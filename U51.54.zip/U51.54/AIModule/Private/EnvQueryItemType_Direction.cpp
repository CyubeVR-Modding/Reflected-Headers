#include "EnvQueryItemType_Direction.h"

UEnvQueryItemType_Direction::UEnvQueryItemType_Direction() {
}

