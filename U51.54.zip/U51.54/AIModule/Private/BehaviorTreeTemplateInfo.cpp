#include "BehaviorTreeTemplateInfo.h"

FBehaviorTreeTemplateInfo::FBehaviorTreeTemplateInfo() {
    this->Asset = NULL;
    this->Template = NULL;
}

