#include "BTTask_PlaySound.h"

UBTTask_PlaySound::UBTTask_PlaySound() {
    this->SoundToPlay = NULL;
}

