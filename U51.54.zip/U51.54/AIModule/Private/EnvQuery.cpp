#include "EnvQuery.h"

UEnvQuery::UEnvQuery() {
    this->QueryName = TEXT("Default__EnvQuery");
}

