#include "AIAsyncTaskBlueprintProxy.h"

void UAIAsyncTaskBlueprintProxy::OnMoveCompleted(FAIRequestID requestID, TEnumAsByte<EPathFollowingResult::Type> MovementResult) {
}

UAIAsyncTaskBlueprintProxy::UAIAsyncTaskBlueprintProxy() {
}

