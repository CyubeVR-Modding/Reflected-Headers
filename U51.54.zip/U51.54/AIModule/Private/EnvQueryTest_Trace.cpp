#include "EnvQueryTest_Trace.h"
#include "EnvQueryContext_Querier.h"

UEnvQueryTest_Trace::UEnvQueryTest_Trace() {
    this->Context = UEnvQueryContext_Querier::StaticClass();
}

