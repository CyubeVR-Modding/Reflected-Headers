#include "AIDataProviderIntValue.h"

FAIDataProviderIntValue::FAIDataProviderIntValue() {
    this->DefaultValue = 0;
}

