#include "GridPathFollowingComponent.h"

UGridPathFollowingComponent::UGridPathFollowingComponent() {
    this->GridManager = NULL;
}

