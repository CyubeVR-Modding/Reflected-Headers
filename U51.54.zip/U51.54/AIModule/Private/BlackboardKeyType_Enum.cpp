#include "BlackboardKeyType_Enum.h"

UBlackboardKeyType_Enum::UBlackboardKeyType_Enum() {
    this->EnumType = NULL;
    this->bIsEnumNameValid = false;
}

