#include "AISenseConfig_Damage.h"
#include "AISense_Damage.h"

UAISenseConfig_Damage::UAISenseConfig_Damage() {
    this->Implementation = UAISense_Damage::StaticClass();
}

