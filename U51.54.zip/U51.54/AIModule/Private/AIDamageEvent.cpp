#include "AIDamageEvent.h"

FAIDamageEvent::FAIDamageEvent() {
    this->Amount = 0.00f;
    this->DamagedActor = NULL;
    this->Instigator = NULL;
}

