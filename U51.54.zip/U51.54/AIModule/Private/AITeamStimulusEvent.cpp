#include "AITeamStimulusEvent.h"

FAITeamStimulusEvent::FAITeamStimulusEvent() {
    this->Broadcaster = NULL;
    this->Enemy = NULL;
}

