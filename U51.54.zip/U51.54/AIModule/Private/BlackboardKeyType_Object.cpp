#include "BlackboardKeyType_Object.h"
//CROSS-MODULE INCLUDE V2: -ModuleName=CoreUObject -ObjectName=Object -FallbackName=Object

UBlackboardKeyType_Object::UBlackboardKeyType_Object() {
    this->BaseClass = UObject::StaticClass();
}

