#pragma once
#include "CoreMinimal.h"
//CROSS-MODULE INCLUDE V2: -ModuleName=CoreUObject -ObjectName=Object -FallbackName=Object
#include "AIHotSpotManager.generated.h"

UCLASS(Blueprintable)
class AIMODULE_API UAIHotSpotManager : public UObject {
    GENERATED_BODY()
public:
    UAIHotSpotManager();
};

