#pragma once
#include "CoreMinimal.h"
#include "BTCompositeNode.h"
#include "BTComposite_Sequence.generated.h"

UCLASS(Blueprintable)
class AIMODULE_API UBTComposite_Sequence : public UBTCompositeNode {
    GENERATED_BODY()
public:
    UBTComposite_Sequence();
};

