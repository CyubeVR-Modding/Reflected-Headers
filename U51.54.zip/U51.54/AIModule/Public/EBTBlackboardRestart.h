#pragma once
#include "CoreMinimal.h"
#include "EBTBlackboardRestart.generated.h"

UENUM(BlueprintType)
namespace EBTBlackboardRestart {
    enum Type {
        ValueChange,
        ResultChange,
    };
}

