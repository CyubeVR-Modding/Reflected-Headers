#pragma once
#include "CoreMinimal.h"
#include "EBlackBoardEntryComparison.generated.h"

UENUM(BlueprintType)
namespace EBlackBoardEntryComparison {
    enum Type {
        Equal,
        NotEqual,
    };
}

