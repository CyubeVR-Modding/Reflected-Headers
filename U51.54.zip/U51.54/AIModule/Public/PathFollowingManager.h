#pragma once
#include "CoreMinimal.h"
//CROSS-MODULE INCLUDE V2: -ModuleName=CoreUObject -ObjectName=Object -FallbackName=Object
#include "PathFollowingManager.generated.h"

UCLASS(Blueprintable)
class AIMODULE_API UPathFollowingManager : public UObject {
    GENERATED_BODY()
public:
    UPathFollowingManager();
};

