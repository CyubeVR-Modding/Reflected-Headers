#pragma once
#include "CoreMinimal.h"
#include "EEnvTestDot.generated.h"

UENUM(BlueprintType)
enum class EEnvTestDot : uint8 {
    Dot3D,
    Dot2D,
};

