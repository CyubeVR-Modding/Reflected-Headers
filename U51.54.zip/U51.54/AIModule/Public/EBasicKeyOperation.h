#pragma once
#include "CoreMinimal.h"
#include "EBasicKeyOperation.generated.h"

UENUM(BlueprintType)
namespace EBasicKeyOperation {
    enum Type {
        Set,
        NotSet,
    };
}

