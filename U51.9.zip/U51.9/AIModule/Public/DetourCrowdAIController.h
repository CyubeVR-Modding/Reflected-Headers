#pragma once
#include "CoreMinimal.h"
#include "AIController.h"
#include "DetourCrowdAIController.generated.h"

UCLASS()
class ADetourCrowdAIController : public AAIController {
    GENERATED_BODY()
public:
    ADetourCrowdAIController();
};

