#pragma once
#include "CoreMinimal.h"
#include "EEnvDirection.generated.h"

UENUM()
namespace EEnvDirection {
    enum Type {
        TwoPoints,
        Rotation,
    };
}

