#pragma once
#include "CoreMinimal.h"
#include "EBlackBoardEntryComparison.generated.h"

UENUM()
namespace EBlackBoardEntryComparison {
    enum Type {
        Equal,
        NotEqual,
    };
}

