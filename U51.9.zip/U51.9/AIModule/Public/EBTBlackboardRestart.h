#pragma once
#include "CoreMinimal.h"
#include "EBTBlackboardRestart.generated.h"

UENUM()
namespace EBTBlackboardRestart {
    enum Type {
        ValueChange,
        ResultChange,
    };
}

