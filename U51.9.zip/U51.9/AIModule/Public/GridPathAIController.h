#pragma once
#include "CoreMinimal.h"
#include "AIController.h"
#include "GridPathAIController.generated.h"

UCLASS()
class AGridPathAIController : public AAIController {
    GENERATED_BODY()
public:
    AGridPathAIController();
};

