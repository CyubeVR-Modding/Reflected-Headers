#pragma once
#include "CoreMinimal.h"
#include "EBTChildIndex.generated.h"

UENUM()
enum class EBTChildIndex {
    FirstNode,
    TaskNode,
};

