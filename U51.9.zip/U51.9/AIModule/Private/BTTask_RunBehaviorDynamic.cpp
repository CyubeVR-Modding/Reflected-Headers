#include "BTTask_RunBehaviorDynamic.h"

UBTTask_RunBehaviorDynamic::UBTTask_RunBehaviorDynamic() {
    this->DefaultBehaviorAsset = NULL;
    this->BehaviorAsset = NULL;
}

