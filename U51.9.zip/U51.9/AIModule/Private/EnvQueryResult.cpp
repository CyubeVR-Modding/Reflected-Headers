#include "EnvQueryResult.h"

FEnvQueryResult::FEnvQueryResult() {
    this->ItemType = NULL;
    this->OptionIndex = 0;
    this->QueryID = 0;
}

