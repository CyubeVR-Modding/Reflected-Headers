#include "BTTask_Wait.h"

UBTTask_Wait::UBTTask_Wait() {
    this->WaitTime = 5.00f;
    this->RandomDeviation = 0.00f;
}

