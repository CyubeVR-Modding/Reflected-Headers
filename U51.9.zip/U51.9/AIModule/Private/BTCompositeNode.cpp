#include "BTCompositeNode.h"

UBTCompositeNode::UBTCompositeNode() {
    this->bApplyDecoratorScope = false;
}

