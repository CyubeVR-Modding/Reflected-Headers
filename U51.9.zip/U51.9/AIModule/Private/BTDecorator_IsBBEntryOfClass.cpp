#include "BTDecorator_IsBBEntryOfClass.h"

UBTDecorator_IsBBEntryOfClass::UBTDecorator_IsBBEntryOfClass() {
    this->TestClass = NULL;
}

