#include "AIDataProvider.h"

UAIDataProvider::UAIDataProvider() {
}

