#include "AIDataProvider_QueryParams.h"

UAIDataProvider_QueryParams::UAIDataProvider_QueryParams() {
    this->FloatValue = 0.00f;
    this->IntValue = 0;
    this->BoolValue = false;
}

