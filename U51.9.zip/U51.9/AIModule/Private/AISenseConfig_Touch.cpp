#include "AISenseConfig_Touch.h"

UAISenseConfig_Touch::UAISenseConfig_Touch() {
}

