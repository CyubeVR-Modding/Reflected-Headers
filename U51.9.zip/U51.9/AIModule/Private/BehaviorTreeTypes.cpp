#include "BehaviorTreeTypes.h"

UBehaviorTreeTypes::UBehaviorTreeTypes() {
}

