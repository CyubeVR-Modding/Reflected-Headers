#include "BTTask_RotateToFaceBBEntry.h"

UBTTask_RotateToFaceBBEntry::UBTTask_RotateToFaceBBEntry() {
    this->Precision = 10.00f;
}

