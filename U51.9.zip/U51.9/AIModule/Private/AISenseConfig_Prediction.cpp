#include "AISenseConfig_Prediction.h"

UAISenseConfig_Prediction::UAISenseConfig_Prediction() {
}

