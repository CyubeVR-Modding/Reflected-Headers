#include "AIDataProviderBoolValue.h"

FAIDataProviderBoolValue::FAIDataProviderBoolValue() {
    this->DefaultValue = false;
}

