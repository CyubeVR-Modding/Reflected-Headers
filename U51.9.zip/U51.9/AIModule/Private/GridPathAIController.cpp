#include "GridPathAIController.h"

AGridPathAIController::AGridPathAIController() {
}

