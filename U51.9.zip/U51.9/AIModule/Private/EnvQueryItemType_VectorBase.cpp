#include "EnvQueryItemType_VectorBase.h"

UEnvQueryItemType_VectorBase::UEnvQueryItemType_VectorBase() {
}

