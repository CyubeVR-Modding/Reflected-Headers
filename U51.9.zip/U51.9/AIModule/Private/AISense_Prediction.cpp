#include "AISense_Prediction.h"

class AActor;
class APawn;
class AAIController;

void UAISense_Prediction::RequestPawnPredictionEvent(APawn* Requestor, AActor* PredictedActor, float PredictionTime) {
}

void UAISense_Prediction::RequestControllerPredictionEvent(AAIController* Requestor, AActor* PredictedActor, float PredictionTime) {
}

UAISense_Prediction::UAISense_Prediction() {
}

