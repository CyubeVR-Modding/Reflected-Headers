#include "BTTask_GameplayTaskBase.h"

UBTTask_GameplayTaskBase::UBTTask_GameplayTaskBase() {
    this->bWaitForGameplayTask = true;
}

