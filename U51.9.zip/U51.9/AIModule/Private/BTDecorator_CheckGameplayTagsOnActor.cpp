#include "BTDecorator_CheckGameplayTagsOnActor.h"

UBTDecorator_CheckGameplayTagsOnActor::UBTDecorator_CheckGameplayTagsOnActor() {
    this->TagsToMatch = EGameplayContainerMatchType::Any;
}

