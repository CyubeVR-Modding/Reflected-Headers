#include "BTDecorator.h"

UBTDecorator::UBTDecorator() {
    this->bInverseCondition = false;
    this->FlowAbortMode = EBTFlowAbortMode::None;
}

