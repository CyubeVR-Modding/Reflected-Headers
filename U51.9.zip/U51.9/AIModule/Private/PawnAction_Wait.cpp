#include "PawnAction_Wait.h"

UPawnAction_Wait::UPawnAction_Wait() {
    this->TimeToWait = 0.00f;
}

