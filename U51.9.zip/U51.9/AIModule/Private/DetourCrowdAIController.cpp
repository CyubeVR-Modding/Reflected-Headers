#include "DetourCrowdAIController.h"

ADetourCrowdAIController::ADetourCrowdAIController() {
}

