#include "AIDataProviderFloatValue.h"

FAIDataProviderFloatValue::FAIDataProviderFloatValue() {
    this->DefaultValue = 0.00f;
}

