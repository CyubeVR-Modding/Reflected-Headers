#include "AIPredictionEvent.h"

FAIPredictionEvent::FAIPredictionEvent() {
    this->Requestor = NULL;
    this->PredictedActor = NULL;
}

