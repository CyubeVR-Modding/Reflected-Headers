#include "BTDecorator_TagCooldown.h"

UBTDecorator_TagCooldown::UBTDecorator_TagCooldown() {
    this->CooldownDuration = 5.00f;
    this->bAddToExistingDuration = false;
    this->bActivatesCooldown = true;
}

