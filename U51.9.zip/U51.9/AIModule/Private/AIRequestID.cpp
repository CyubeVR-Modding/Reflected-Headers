#include "AIRequestID.h"

FAIRequestID::FAIRequestID() {
    this->requestID = 0;
}

