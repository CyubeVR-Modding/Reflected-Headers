#include "EnvQueryOption.h"

UEnvQueryOption::UEnvQueryOption() {
    this->Generator = NULL;
}

