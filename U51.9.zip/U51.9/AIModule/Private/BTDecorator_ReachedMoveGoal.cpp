#include "BTDecorator_ReachedMoveGoal.h"

UBTDecorator_ReachedMoveGoal::UBTDecorator_ReachedMoveGoal() {
}

