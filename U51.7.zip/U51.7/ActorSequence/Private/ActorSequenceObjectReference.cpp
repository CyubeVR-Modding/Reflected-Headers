#include "ActorSequenceObjectReference.h"

FActorSequenceObjectReference::FActorSequenceObjectReference() {
    this->Type = EActorSequenceObjectReferenceType::ContextActor;
}

