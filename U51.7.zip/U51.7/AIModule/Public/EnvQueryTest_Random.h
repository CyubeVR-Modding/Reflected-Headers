#pragma once
#include "CoreMinimal.h"
#include "EnvQueryTest.h"
#include "EnvQueryTest_Random.generated.h"

UCLASS(MinimalAPI)
class UEnvQueryTest_Random : public UEnvQueryTest {
    GENERATED_BODY()
public:
    UEnvQueryTest_Random();
};

