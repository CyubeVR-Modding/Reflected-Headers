#pragma once
#include "CoreMinimal.h"
#include "EEnvTestFilterOperator.generated.h"

UENUM()
namespace EEnvTestFilterOperator {
    enum Type {
        AllPass,
        AnyPass,
    };
}

