#pragma once
#include "CoreMinimal.h"
#include "BTCompositeNode.h"
#include "BTComposite_Selector.generated.h"

UCLASS()
class AIMODULE_API UBTComposite_Selector : public UBTCompositeNode {
    GENERATED_BODY()
public:
    UBTComposite_Selector();
};

