#pragma once
#include "CoreMinimal.h"
#include "EEnvTestDot.generated.h"

UENUM()
enum class EEnvTestDot : uint8 {
    Dot3D,
    Dot2D,
};

