#include "BehaviorTree.h"

UBehaviorTree::UBehaviorTree() {
    this->RootNode = NULL;
    this->BlackboardAsset = NULL;
}

