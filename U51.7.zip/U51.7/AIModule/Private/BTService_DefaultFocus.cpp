#include "BTService_DefaultFocus.h"

UBTService_DefaultFocus::UBTService_DefaultFocus() {
    this->FocusPriority = 0;
}

