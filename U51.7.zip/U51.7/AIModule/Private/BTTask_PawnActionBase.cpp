#include "BTTask_PawnActionBase.h"

UBTTask_PawnActionBase::UBTTask_PawnActionBase() {
}

