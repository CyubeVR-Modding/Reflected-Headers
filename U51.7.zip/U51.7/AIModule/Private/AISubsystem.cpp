#include "AISubsystem.h"

UAISubsystem::UAISubsystem() {
    this->AISystem = NULL;
}

