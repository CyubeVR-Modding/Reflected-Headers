#include "AISenseConfig_Blueprint.h"

UAISenseConfig_Blueprint::UAISenseConfig_Blueprint() {
    this->Implementation = NULL;
}

