#include "BTTask_PushPawnAction.h"

UBTTask_PushPawnAction::UBTTask_PushPawnAction() {
    this->Action = NULL;
}

