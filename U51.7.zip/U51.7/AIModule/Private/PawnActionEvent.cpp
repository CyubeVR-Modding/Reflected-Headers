#include "PawnActionEvent.h"

FPawnActionEvent::FPawnActionEvent() {
    this->Action = NULL;
}

