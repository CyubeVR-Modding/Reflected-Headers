#include "EnvNamedValue.h"

FEnvNamedValue::FEnvNamedValue() {
    this->ParamType = EAIParamType::Float;
    this->Value = 0.00f;
}

