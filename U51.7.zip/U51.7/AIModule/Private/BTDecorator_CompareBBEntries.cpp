#include "BTDecorator_CompareBBEntries.h"

UBTDecorator_CompareBBEntries::UBTDecorator_CompareBBEntries() {
    this->Operator = EBlackBoardEntryComparison::Equal;
}

