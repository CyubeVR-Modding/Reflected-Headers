#include "ActorPerceptionUpdateInfo.h"

FActorPerceptionUpdateInfo::FActorPerceptionUpdateInfo() {
    this->TargetId = 0;
}

