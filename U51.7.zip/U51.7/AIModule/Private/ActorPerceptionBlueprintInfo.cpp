#include "ActorPerceptionBlueprintInfo.h"

FActorPerceptionBlueprintInfo::FActorPerceptionBlueprintInfo() {
    this->Target = NULL;
    this->bIsHostile = false;
}

