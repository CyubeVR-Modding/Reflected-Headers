#include "BTNode.h"

UBTNode::UBTNode() {
    this->TreeAsset = NULL;
    this->ParentNode = NULL;
}

