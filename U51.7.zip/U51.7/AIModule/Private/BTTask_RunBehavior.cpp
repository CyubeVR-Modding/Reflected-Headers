#include "BTTask_RunBehavior.h"

UBTTask_RunBehavior::UBTTask_RunBehavior() {
    this->BehaviorAsset = NULL;
}

