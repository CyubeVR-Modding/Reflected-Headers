#include "BlackboardKeyType_Class.h"
//CROSS-MODULE INCLUDE V2: -ModuleName=CoreUObject -ObjectName=Object -FallbackName=Object

UBlackboardKeyType_Class::UBlackboardKeyType_Class() {
    this->BaseClass = UObject::StaticClass();
}

