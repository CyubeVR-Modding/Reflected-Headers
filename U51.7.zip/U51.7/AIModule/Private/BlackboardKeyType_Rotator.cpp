#include "BlackboardKeyType_Rotator.h"

UBlackboardKeyType_Rotator::UBlackboardKeyType_Rotator() {
}

