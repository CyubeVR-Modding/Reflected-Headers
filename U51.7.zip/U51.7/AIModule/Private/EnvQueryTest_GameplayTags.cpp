#include "EnvQueryTest_GameplayTags.h"

UEnvQueryTest_GameplayTags::UEnvQueryTest_GameplayTags() {
    this->bUpdatedToUseQuery = false;
    this->TagsToMatch = EGameplayContainerMatchType::Any;
}

