#include "AIDataProviderStructValue.h"

FAIDataProviderStructValue::FAIDataProviderStructValue() {
}

