#include "AIDataProvider_Random.h"

UAIDataProvider_Random::UAIDataProvider_Random() {
    this->Min = 0.00f;
    this->Max = 1.00f;
    this->bInteger = false;
}

