#include "BTComposite_SimpleParallel.h"

UBTComposite_SimpleParallel::UBTComposite_SimpleParallel() {
    this->FinishMode = EBTParallelMode::AbortBackground;
}

