#include "AIDataProviderValue.h"

FAIDataProviderValue::FAIDataProviderValue() {
    this->DataBinding = NULL;
}

