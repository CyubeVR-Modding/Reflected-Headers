#include "BTTask_FinishWithResult.h"

UBTTask_FinishWithResult::UBTTask_FinishWithResult() {
    this->Result = EBTNodeResult::Succeeded;
}

