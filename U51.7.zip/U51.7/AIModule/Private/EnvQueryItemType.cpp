#include "EnvQueryItemType.h"

UEnvQueryItemType::UEnvQueryItemType() {
}

