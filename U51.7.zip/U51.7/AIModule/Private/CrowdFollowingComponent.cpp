#include "CrowdFollowingComponent.h"

void UCrowdFollowingComponent::SuspendCrowdSteering(bool bSuspend) {
}

UCrowdFollowingComponent::UCrowdFollowingComponent() {
}

