#include "EnvQueryGenerator_Composite.h"

UEnvQueryGenerator_Composite::UEnvQueryGenerator_Composite() {
    this->bAllowDifferentItemTypes = false;
    this->bHasMatchingItemType = true;
    this->ForcedItemType = NULL;
}

