#include "BlackboardKeyType_NativeEnum.h"

UBlackboardKeyType_NativeEnum::UBlackboardKeyType_NativeEnum() {
    this->EnumType = NULL;
}

